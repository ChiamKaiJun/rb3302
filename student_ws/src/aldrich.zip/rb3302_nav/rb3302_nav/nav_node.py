"""ROS 2 glue node: same algorithms as simulation/, topics from robot_ws.

Copy ../simulation/*.py next to this package (or set RB3302_SIM_PATH)
on the course laptop, then:

  ros2 run rb3302_nav nav_node --ros-args -p goals:=['T','N','H','A'] -p start:=S
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np

try:
    import rclpy
    from geometry_msgs.msg import Twist
    from nav_msgs.msg import OccupancyGrid, Odometry
    from rclpy.node import Node
    from sensor_msgs.msg import Imu, LaserScan
except ImportError:  # macOS / no ROS: keep this file as the interface contract
    rclpy = None
    Node = object  # type: ignore


def _add_sim_path() -> None:
    env = os.environ.get("RB3302_SIM_PATH")
    candidates = [
        Path(env) if env else None,
        Path(__file__).resolve().parents[4] / "simulation",
        Path.home() / "RB3302" / "simulation",
    ]
    for p in candidates:
        if p and p.is_dir():
            sys.path.insert(0, str(p))
            return


_add_sim_path()


class NavNode(Node):
    def __init__(self) -> None:
        super().__init__("rb3302_nav")
        self.declare_parameter("start", "S")
        self.declare_parameter("goals", ["T", "N", "H", "A"])
        self.declare_parameter("desired_linear_vel", 0.22)
        self.declare_parameter("dwell_s", 3.0)
        self.pub = self.create_publisher(Twist, "/cmd_vel", 10)
        self.create_subscription(LaserScan, "/scan", self._on_scan, 10)
        self.create_subscription(Odometry, "/odom", self._on_odom, 10)
        self.create_subscription(Imu, "/imu_data_ros", self._on_imu, 10)
        self.create_subscription(OccupancyGrid, "/map", self._on_map, 10)
        self.scan = None
        self.odom = None
        self.imu = None
        self.map_msg = None
        self.timer = self.create_timer(0.05, self._tick)
        self.get_logger().info(
            "rb3302_nav up. Port simulation/topo.py + rpp.py + amcl.py here; "
            "this node only wires /scan /odom /imu_data_ros /map → /cmd_vel."
        )

    def _on_scan(self, msg: "LaserScan") -> None:
        self.scan = msg

    def _on_odom(self, msg: "Odometry") -> None:
        self.odom = msg

    def _on_imu(self, msg: "Imu") -> None:
        self.imu = msg

    def _on_map(self, msg: "OccupancyGrid") -> None:
        self.map_msg = msg

    def _tick(self) -> None:
        cmd = Twist()
        if self.scan is None or self.odom is None:
            self.pub.publish(cmd)
            return
        # Hook: convert ROS messages → numpy, call AMCL / topo / RPP, fill cmd.
        # Keep the same units as simulation/ (metres, rad, m/s).
        cmd.linear.x = 0.0
        cmd.angular.z = 0.0
        self.pub.publish(cmd)


def main() -> None:
    if rclpy is None:
        print("rclpy not found. Run this on the lab PC / robot after sourcing ROS 2 Jazzy.")
        sys.exit(1)
    rclpy.init()
    node = NavNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
