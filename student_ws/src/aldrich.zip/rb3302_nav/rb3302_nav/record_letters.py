"""Record A–X map coordinates from RViz Publish Point into course_letters.yaml.

RViz tool Publish Point publishes geometry_msgs/PointStamped on /clicked_point.
This node writes each click so you do not type x/y by hand.

  source ~/rb3302_final_proj_code/student_ws/install/setup.bash
  ros2 run rb3302_nav record_letters

Then in RViz click letter centers in order A, B, C, ... X.
Ctrl+C saves whatever you have and exits.
"""

from __future__ import annotations

from pathlib import Path

import yaml

try:
    import rclpy
    from geometry_msgs.msg import PointStamped
    from rclpy.node import Node
except ImportError:
    rclpy = None
    Node = object  # type: ignore
    PointStamped = object  # type: ignore


LETTERS = [chr(ord("A") + i) for i in range(24)]


def default_out() -> str:
    return str(
        Path.home()
        / "rb3302_final_proj_code"
        / "student_ws"
        / "src"
        / "rb3302_nav"
        / "config"
        / "course_letters.yaml"
    )


class LetterRecorder(Node):
    def __init__(self) -> None:
        super().__init__("record_letters")
        self.declare_parameter("topic", "/clicked_point")
        self.declare_parameter("out_file", default_out())
        self.declare_parameter("start_letter", "A")
        self.out = Path(str(self.get_parameter("out_file").value)).expanduser()
        start = str(self.get_parameter("start_letter").value).strip().upper()
        if start not in LETTERS:
            raise SystemExit(f"start_letter must be A–X, got {start}")
        self.idx = LETTERS.index(start)
        self.letters: dict[str, dict[str, float]] = {}
        if self.out.exists():
            data = yaml.safe_load(self.out.read_text()) or {}
            existing = data.get("letters") or {}
            for L, pose in existing.items():
                self.letters[str(L).upper()] = {
                    "x": float(pose["x"]),
                    "y": float(pose["y"]),
                    "yaw": float(pose.get("yaw", 0.0)),
                }
        self.create_subscription(PointStamped, str(self.get_parameter("topic").value), self._on_click, 10)
        nxt = LETTERS[self.idx] if self.idx < len(LETTERS) else None
        self.get_logger().info(f"writing {self.out}")
        if nxt:
            self.get_logger().info(f"RViz: Publish Point, click center of {nxt} (then {LETTERS[self.idx+1] if self.idx+1 < 24 else 'done'})")
        else:
            self.get_logger().info("all 24 letters already past start_letter; Ctrl+C to quit")

    def _on_click(self, msg: PointStamped) -> None:
        if self.idx >= len(LETTERS):
            self.get_logger().warn("already have A–X; extra click ignored")
            return
        letter = LETTERS[self.idx]
        x, y = float(msg.point.x), float(msg.point.y)
        self.letters[letter] = {"x": round(x, 4), "y": round(y, 4), "yaw": 0.0}
        self.idx += 1
        self._save()
        self.get_logger().info(f"saved {letter}: x={x:.4f} y={y:.4f}")
        if self.idx < len(LETTERS):
            self.get_logger().info(f"next: click {LETTERS[self.idx]}")
        else:
            self.get_logger().info("done A–X. Ctrl+C, then colcon build --packages-select rb3302_nav")

    def _save(self) -> None:
        self.out.parent.mkdir(parents=True, exist_ok=True)
        ordered = {L: self.letters[L] for L in LETTERS if L in self.letters}
        payload = {
            "origin_x": 0.0,
            "origin_y": 0.0,
            "pitch_x": 0.68,
            "pitch_y": 0.68,
            "letters": ordered,
        }
        self.out.write_text(yaml.safe_dump(payload, sort_keys=False, allow_unicode=True))


def main() -> None:
    if rclpy is None:
        print("rclpy not found. Run record_letters on the lab laptop / robot (ROS 2 Jazzy).")
        print("Fallback: ros2 topic echo /clicked_point")
        raise SystemExit(1)
    rclpy.init()
    node = LetterRecorder()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("stopped")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
