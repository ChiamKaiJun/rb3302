"""Send Nav2 goals to A–X letter squares and dwell 3 seconds on each.

Program ALL run inputs before the clock starts. After 2D Pose Estimate, do not
touch the robot until this node finishes (or you verbally skip a missed landmark).

  ros2 run rb3302_nav exam_runner --ros-args \
    -p start:=S -p bearing:=E \
    -p goals:="['T','N','H','A']" \
    -p dwell_s:=3.0 -p skip_timeout_s:=50.0

Goals may repeat. If Nav2 does not finish a landmark in skip_timeout_s, that
path is skipped (0 points) and the next programmed goal is sent.
"""

from __future__ import annotations

import math
import time
from pathlib import Path

import yaml

try:
    from action_msgs.msg import GoalStatus
    import rclpy
    from geometry_msgs.msg import PoseStamped
    from nav2_msgs.action import NavigateToPose
    from rclpy.action import ActionClient
    from rclpy.node import Node
except ImportError:
    rclpy = None
    Node = object  # type: ignore
    GoalStatus = None  # type: ignore


LETTERS = [chr(ord("A") + i) for i in range(24)]
COMPASS_YAW = {
    "E": 0.0,
    "NE": math.pi / 4,
    "N": math.pi / 2,
    "NW": 3 * math.pi / 4,
    "W": math.pi,
    "SW": -3 * math.pi / 4,
    "S": -math.pi / 2,
    "SE": -math.pi / 4,
}


def letter_grid_xy(letter: str, origin_x: float, origin_y: float, pitch_x: float, pitch_y: float) -> tuple[float, float]:
    idx = ord(letter.upper()) - ord("A")
    col = idx % 6
    row_from_top = idx // 6
    row = 3 - row_from_top
    return origin_x + col * pitch_x, origin_y + row * pitch_y


def yaw_to_quat(yaw: float) -> tuple[float, float, float, float]:
    return 0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0)


def compass_to_yaw(name: str) -> float:
    key = str(name).strip().upper()
    if key not in COMPASS_YAW:
        raise ValueError(f"bearing must be one of {sorted(COMPASS_YAW)}")
    return COMPASS_YAW[key]


class ExamRunner(Node):
    def __init__(self) -> None:
        super().__init__("exam_runner")
        self.declare_parameter("start", "S")
        self.declare_parameter("bearing", "E")
        self.declare_parameter("goals", ["T", "N", "H", "A"])
        self.declare_parameter("dwell_s", 3.0)
        self.declare_parameter("skip_timeout_s", 50.0)
        self.declare_parameter("course_file", "")
        self.declare_parameter("action_name", "navigate_to_pose")
        self.client = ActionClient(self, NavigateToPose, self.get_parameter("action_name").value)
        self.poses = self._load_course()
        start = str(self.get_parameter("start").value).upper()
        bearing = str(self.get_parameter("bearing").value).upper()
        goals = [str(g).upper() for g in self.get_parameter("goals").value]
        dwell = float(self.get_parameter("dwell_s").value)
        skip = float(self.get_parameter("skip_timeout_s").value)
        yaw = compass_to_yaw(bearing)
        self.get_logger().info(
            "PROGRAMMED (do not change until next run): "
            f"start={start} bearing={bearing} ({yaw:.3f} rad ±45°) "
            f"goals={goals} dwell={dwell:.1f}s skip_timeout={skip:.1f}s"
        )

    def _load_course(self) -> dict[str, tuple[float, float, float]]:
        path = self.get_parameter("course_file").value
        data = {}
        candidates = []
        if path:
            candidates.append(Path(path))
        try:
            from ament_index_python.packages import get_package_share_directory

            candidates.append(Path(get_package_share_directory("rb3302_nav")) / "config" / "course_letters.yaml")
        except Exception:
            pass
        candidates.append(
            Path.home()
            / "rb3302_final_proj_code"
            / "student_ws"
            / "src"
            / "rb3302_nav"
            / "config"
            / "course_letters.yaml"
        )
        for cand in candidates:
            if cand.exists():
                data = yaml.safe_load(cand.read_text()) or {}
                self.get_logger().info(f"loaded course file {cand}")
                break
        origin_x = float(data.get("origin_x", 0.48))
        origin_y = float(data.get("origin_y", 0.48))
        pitch_x = float(data.get("pitch_x", 0.68))
        pitch_y = float(data.get("pitch_y", 0.68))
        explicit = data.get("letters") or {}
        out = {}
        for L in LETTERS:
            if L in explicit:
                out[L] = (
                    float(explicit[L]["x"]),
                    float(explicit[L]["y"]),
                    float(explicit[L].get("yaw", 0.0)),
                )
            else:
                x, y = letter_grid_xy(L, origin_x, origin_y, pitch_x, pitch_y)
                out[L] = (x, y, 0.0)
        return out

    def _goal(self, letter: str) -> NavigateToPose.Goal:
        x, y, yaw = self.poses[letter.upper()]
        qx, qy, qz, qw = yaw_to_quat(yaw)
        pose = PoseStamped()
        pose.header.frame_id = "map"
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x = x
        pose.pose.position.y = y
        pose.pose.orientation.x = qx
        pose.pose.orientation.y = qy
        pose.pose.orientation.z = qz
        pose.pose.orientation.w = qw
        goal = NavigateToPose.Goal()
        goal.pose = pose
        return goal

    def _wait_result(self, handle, timeout_s: float) -> bool:
        result_future = handle.get_result_async()
        deadline = time.monotonic() + max(timeout_s, 0.1)
        while rclpy.ok() and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.1)
            if result_future.done():
                res = result_future.result()
                status = getattr(res, "status", GoalStatus.STATUS_UNKNOWN)
                return status == GoalStatus.STATUS_SUCCEEDED
        handle.cancel_goal_async()
        for _ in range(20):
            rclpy.spin_once(self, timeout_sec=0.05)
        return False

    def run(self) -> None:
        goals = [str(g).upper() for g in self.get_parameter("goals").value]
        dwell = float(self.get_parameter("dwell_s").value)
        skip = float(self.get_parameter("skip_timeout_s").value)
        self.get_logger().info("waiting for Nav2 /navigate_to_pose ...")
        if not self.client.wait_for_server(timeout_sec=30.0):
            self.get_logger().error("Nav2 action server not up. Start planning_*.launch.py first.")
            return
        for letter in goals:
            self.get_logger().info(f"navigating to {letter} {self.poses[letter][:2]}")
            send = self.client.send_goal_async(self._goal(letter))
            rclpy.spin_until_future_complete(self, send)
            handle = send.result()
            if handle is None or not handle.accepted:
                self.get_logger().error(f"{letter} goal rejected — SKIP (0 pts this path)")
                continue
            ok = self._wait_result(handle, skip)
            if not ok:
                self.get_logger().warn(
                    f"{letter} not reached in {skip:.0f}s — SKIP (0 pts this path, continue)"
                )
                continue
            self.get_logger().info(f"reached {letter}, dwelling {dwell:.1f}s")
            self.get_clock().sleep_for(rclpy.duration.Duration(seconds=dwell))
        self.get_logger().info("exam sequence done")


def main() -> None:
    if rclpy is None:
        print("rclpy not found. Run exam_runner on the lab laptop / robot (ROS 2 Jazzy).")
        raise SystemExit(1)
    rclpy.init()
    node = ExamRunner()
    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
