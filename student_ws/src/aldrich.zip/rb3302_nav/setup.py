from glob import glob

from setuptools import setup

package_name = "rb3302_nav"

setup(
    name=package_name,
    version="0.1.0",
    packages=[package_name],
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
        ("share/" + package_name + "/config", glob("config/*")),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    entry_points={
        "console_scripts": [
            "nav_node = rb3302_nav.nav_node:main",
            "exam_runner = rb3302_nav.exam_runner:main",
            "record_letters = rb3302_nav.record_letters:main",
        ]
    },
)
